import { useRef } from 'react'
import gsap from 'gsap'
import { useGSAP } from '@gsap/react'
import { RotateCcw } from 'lucide-react'
import { Button, MetaLabel, motionTokens } from '../index'

gsap.registerPlugin(useGSAP)

const { duration, ease, stagger, distance, prefersReducedMotion } = motionTokens

/** Demonstrates the three sanctioned GSAP patterns with scoped selectors. */
export default function MotionDemo() {
  const scope = useRef<HTMLDivElement>(null)
  const { contextSafe } = useGSAP({ scope })

  const play = contextSafe(() => {
    if (prefersReducedMotion()) return
    const tl = gsap.timeline()
    tl.from('.demo-tile', { y: distance.md, autoAlpha: 0, duration: duration.slow, ease: ease.out, stagger: stagger.base })
      .from('.demo-bar', { scaleX: 0, transformOrigin: 'left center', duration: duration.epic, ease: ease.inOut }, '<0.1')
      .from('.demo-node', { scale: 0, duration: duration.base, ease: ease.snap }, '-=0.4')
  })

  return (
    <div ref={scope} className="flex flex-col gap-6 rounded-lg border border-border bg-surface p-6 md:p-8">
      <div className="flex items-center justify-between gap-4">
        <MetaLabel index="M-01">Entrance sequence</MetaLabel>
        <Button variant="secondary" size="sm" iconStart={<RotateCcw className="size-4" />} onClick={play}>
          Replay
        </Button>
      </div>
      <div className="grid grid-cols-3 gap-3">
        {['stagger', 'reveal', 'settle'].map((l, i) => (
          <div key={l} className="demo-tile flex aspect-square flex-col justify-between rounded-md border border-border-strong bg-surface-raised p-4">
            <span className="font-mono text-micro uppercase text-fg-subtle">0{i + 1}</span>
            <span className="font-display text-title font-semibold text-fg">{l}</span>
          </div>
        ))}
      </div>
      <div className="relative h-1 overflow-hidden rounded-pill bg-border">
        <div className="demo-bar absolute inset-0 bg-gradient-to-r from-primary to-secondary" />
      </div>
      <div className="flex items-center gap-3">
        <span className="demo-node size-3 rotate-45 bg-highlight" />
        <span className="font-mono text-label text-fg-muted">expo.out · 600ms · stagger 80ms → power4.inOut 1000ms → back.out 320ms</span>
      </div>
    </div>
  )
}
