import { useMemo, useState, type ReactNode } from 'react'
import clsx from 'clsx'
import { ArrowRight, Check, Keyboard, Mail, Rss, SearchX, Sparkles, X } from 'lucide-react'
import {
  Badge,
  Button,
  Container,
  CTASection,
  EmptyState,
  ErrorState,
  FeaturedProject,
  FilterGroup,
  GitHubMark,
  IconButton,
  LogoMark,
  MetaLabel,
  ProjectCard,
  ProjectCardSkeleton,
  Reveal,
  SearchField,
  SectionHeader,
  SiteFooter,
  SiteNav,
  Stat,
  StatGroup,
  StatusIndicator,
  Tag,
  TextLink,
  Timeline,
  TimelineItem,
} from '../index'
import { projects } from './data'
import MotionDemo from './MotionDemo'

const nav = [
  { label: 'Foundations', href: '#color' },
  { label: 'Components', href: '#components' },
  { label: 'Projects', href: '#projects' },
  { label: 'Motion', href: '#motion' },
  { label: 'Access', href: '#a11y' },
]

function Section({ id, children, className }: { id: string; children: ReactNode; className?: string }) {
  return (
    <Container as="section" id={id} className={clsx('scroll-mt-20 py-20 md:py-28', className)}>
      {children}
    </Container>
  )
}

function Panel({ label, children, className }: { label: string; children: ReactNode; className?: string }) {
  return (
    <div className={clsx('flex flex-col gap-5 rounded-lg border border-border bg-surface p-6', className)}>
      <span className="font-mono text-micro uppercase text-fg-subtle">{label}</span>
      {children}
    </div>
  )
}

/* ------------------------------------------------------------------ */

const palette = [
  { name: 'Midnight', hex: '#080B14', role: 'Background', cls: 'bg-midnight border border-border-strong', ratio: 'basis-[62%]' },
  { name: 'Electric Violet', hex: '#8B5CF6', role: 'Primary brand', cls: 'bg-violet', ratio: 'basis-[20%]' },
  { name: 'Cyber Cyan', hex: '#22D3EE', role: 'Secondary · focus', cls: 'bg-cyan', ratio: 'basis-[11%]' },
  { name: 'Acid Lime', hex: '#C4F750', role: 'Highlight · rare', cls: 'bg-lime', ratio: 'basis-[5%]' },
  { name: 'Coral', hex: '#FB7185', role: 'Contrast · rare', cls: 'bg-coral', ratio: 'basis-[2%]' },
]

const semantic = [
  ['bg', 'bg-bg border border-border-strong', 'Page canvas'],
  ['surface', 'bg-surface border border-border', 'Cards, panels'],
  ['surface-raised', 'bg-surface-raised', 'Hover, nested'],
  ['border', 'bg-border', 'Hairlines'],
  ['border-strong', 'bg-border-strong', 'Inputs, emphasis'],
  ['fg', 'bg-fg', 'Headings · 18.1:1'],
  ['fg-muted', 'bg-fg-muted', 'Body support · 8.4:1'],
  ['fg-subtle', 'bg-fg-subtle', 'Meta only · 5.9:1'],
  ['primary-fill', 'bg-primary-fill', 'Primary buttons · 5.7:1 w/ white'],
  ['primary-text', 'bg-primary-text', 'Violet text on dark'],
  ['focus', 'bg-focus', 'Focus ring'],
  ['success', 'bg-success', 'Positive state'],
  ['warning', 'bg-warning', 'Caution state'],
  ['error', 'bg-error', 'Error state'],
]

function ColorSection() {
  return (
    <Section id="color">
      <SectionHeader
        index="01"
        eyebrow="Color"
        title={<>Midnight first. Accents are <span className="text-gradient-brand">earned.</span></>}
        description="The canvas is always dark. Violet carries the brand, cyan carries interaction, lime and coral appear as single sparks — never side by side."
      />
      <Reveal className="mt-14 flex flex-col gap-3">
        <div data-reveal className="flex h-40 gap-1 overflow-hidden rounded-lg md:h-56">
          {palette.map((c) => (
            <div key={c.name} className={clsx('min-w-6 rounded-sm', c.cls, c.ratio)} />
          ))}
        </div>
        <p data-reveal className="font-mono text-label text-fg-subtle">Usage ratio by area — 62 / 20 / 11 / 5 / 2</p>
        <div data-reveal className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-5">
          {palette.map((c) => (
            <div key={c.name} className="flex flex-col gap-2 border-t border-border pt-4">
              <span className={clsx('size-6 rounded-xs', c.cls)} />
              <span className="font-display text-title font-semibold">{c.name}</span>
              <span className="font-mono text-label text-fg-muted">{c.hex}</span>
              <span className="text-body-sm text-fg-subtle">{c.role}</span>
            </div>
          ))}
        </div>
      </Reveal>
      <div className="mt-16 grid gap-px overflow-hidden rounded-lg border border-border bg-border sm:grid-cols-2 lg:grid-cols-3">
        {semantic.map(([token, cls, note]) => (
          <div key={token} className="flex items-center gap-4 bg-bg p-4">
            <span className={clsx('size-10 shrink-0 rounded-sm', cls)} />
            <div className="flex flex-col">
              <span className="font-mono text-body-sm text-fg">--color-{token}</span>
              <span className="text-body-sm text-fg-subtle">{note}</span>
            </div>
          </div>
        ))}
      </div>
    </Section>
  )
}

function TypeSection() {
  const rows = [
    { token: 'display-2xl', cls: 'font-display text-display-2xl font-semibold', sample: 'Ship weird.', meta: 'Space Grotesk 600 · 48→112 · lh .92 · -4.5%' },
    { token: 'display-xl', cls: 'font-display text-display-xl font-semibold', sample: 'Section titles', meta: 'Space Grotesk 600 · 40→76 · lh .98' },
    { token: 'display-lg', cls: 'font-display text-display-lg font-semibold', sample: 'Featured project', meta: 'Space Grotesk 600 · 32→52' },
    { token: 'display-md', cls: 'font-display text-display-md font-semibold', sample: 'Stat values & subheads', meta: 'Space Grotesk 600 · 24→34' },
    { token: 'title', cls: 'font-display text-title font-semibold', sample: 'Card title — Orbit CLI', meta: 'Space Grotesk 600 · 20' },
    { token: 'body-lg', cls: 'text-body-lg text-fg-soft', sample: 'Lead paragraphs introduce a section in one or two sentences.', meta: 'Inter 400 · 18 · lh 1.65' },
    { token: 'body', cls: 'text-body text-fg-soft', sample: 'Body copy stays under 68 characters per line for comfortable reading.', meta: 'Inter 400 · 16 · lh 1.6' },
    { token: 'label', cls: 'font-mono text-label uppercase text-fg-muted', sample: 'TN-014 / experiments / 2025', meta: 'JetBrains Mono 500 · 12 · +8%' },
  ]
  return (
    <Section id="type" className="border-t border-border">
      <SectionHeader index="02" eyebrow="Typography" title="Three voices, one rhythm." description="Space Grotesk speaks. Inter explains. JetBrains Mono annotates. Never swap their jobs." />
      <div className="mt-14 divide-y divide-border border-y border-border">
        {rows.map((r) => (
          <div key={r.token} className="grid gap-3 py-6 lg:grid-cols-12 lg:items-baseline">
            <div className="flex flex-col gap-1 lg:col-span-3">
              <span className="font-mono text-label text-primary-text">text-{r.token}</span>
              <span className="font-mono text-micro text-fg-subtle">{r.meta}</span>
            </div>
            <p className={clsx('lg:col-span-9', r.cls)}>{r.sample}</p>
          </div>
        ))}
      </div>
      <div className="mt-10 grid gap-6 md:grid-cols-3">
        <Panel label="Display — Space Grotesk"><p className="font-display text-display-lg font-bold">Aa Gg 0123</p></Panel>
        <Panel label="UI & body — Inter"><p className="font-sans text-display-lg font-semibold">Aa Gg 0123</p></Panel>
        <Panel label="Technical — JetBrains Mono"><p className="font-mono text-display-lg font-medium">{'{ } => 01'}</p></Panel>
      </div>
    </Section>
  )
}

function LayoutSection() {
  const space = [
    ['1', 'w-1', '4'], ['2', 'w-2', '8'], ['3', 'w-3', '12'], ['4', 'w-4', '16'], ['6', 'w-6', '24'],
    ['8', 'w-8', '32'], ['12', 'w-12', '48'], ['16', 'w-16', '64'], ['20', 'w-20', '80'], ['28', 'w-28', '112'],
  ]
  const radii = [['xs', 'rounded-xs', 'tags'], ['sm', 'rounded-sm', 'small btn'], ['md', 'rounded-md', 'buttons, inputs'], ['lg', 'rounded-lg', 'cards'], ['xl', 'rounded-xl', 'feature, CTA'], ['pill', 'rounded-pill', 'badges, filters']]
  return (
    <Section id="layout" className="border-t border-border">
      <SectionHeader index="03" eyebrow="Grid · Space · Geometry" title="A 12-column grid, broken on purpose." description="Content snaps to the grid; emphasis comes from asymmetric spans (7/5, 8/4) instead of rows of identical boxes." />
      <div className="relative mt-14 overflow-hidden rounded-lg border border-border p-4 md:p-6">
        <div className="grid grid-cols-4 gap-3 md:grid-cols-8 lg:grid-cols-12 lg:gap-6">
          {Array.from({ length: 12 }).map((_, i) => (
            <div key={i} className={clsx('h-24 rounded-xs bg-primary/10 ring-1 ring-primary/30 ring-inset', i >= 4 && 'hidden md:block', i >= 8 && 'md:hidden lg:block')} />
          ))}
        </div>
        <div className="mt-3 grid grid-cols-4 gap-3 md:grid-cols-8 lg:grid-cols-12 lg:gap-6">
          <div className="col-span-4 flex h-20 items-end rounded-sm bg-surface-raised p-3 font-mono text-micro uppercase text-fg-muted md:col-span-5 lg:col-span-7">span 7 — media</div>
          <div className="col-span-4 flex h-20 items-end rounded-sm bg-surface-raised p-3 font-mono text-micro uppercase text-fg-muted md:col-span-3 lg:col-span-5">span 5 — copy</div>
        </div>
        <p className="mt-4 font-mono text-label text-fg-subtle">4 cols · gap 12 (base) → 8 cols (md) → 12 cols · gap 24 (lg) · max 1280 · gutters 20/32/48</p>
      </div>
      <div className="mt-10 grid gap-6 lg:grid-cols-12">
        <Panel label="Spacing scale — 4px base" className="lg:col-span-5">
          <div className="flex flex-col gap-2.5">
            {space.map(([k, w, px]) => (
              <div key={k} className="flex items-center gap-4">
                <span className="w-10 font-mono text-label text-fg-muted">{k}</span>
                <span className={clsx('h-3 rounded-xs bg-secondary', w)} />
                <span className="font-mono text-micro text-fg-subtle">{px}px</span>
              </div>
            ))}
          </div>
        </Panel>
        <div className="grid gap-6 lg:col-span-7">
          <Panel label="Radius">
            <div className="grid grid-cols-3 gap-4 sm:grid-cols-6">
              {radii.map(([k, cls, use]) => (
                <div key={k} className="flex flex-col gap-2">
                  <div className={clsx('aspect-square border border-primary/60 bg-primary/10', cls)} />
                  <span className="font-mono text-label text-fg">{k}</span>
                  <span className="text-body-sm text-fg-subtle">{use}</span>
                </div>
              ))}
            </div>
          </Panel>
          <Panel label="Surfaces & elevation">
            <div className="grid gap-4 sm:grid-cols-3">
              <div className="flex h-28 items-end rounded-lg border border-border bg-bg p-4 font-mono text-micro uppercase text-fg-muted">bg · level 0</div>
              <div className="flex h-28 items-end rounded-lg border border-border bg-surface-raised p-4 font-mono text-micro uppercase text-fg-muted shadow-raised">raised · level 1</div>
              <div className="flex h-28 items-end rounded-lg bg-surface p-4 font-mono text-micro uppercase text-fg shadow-glow-primary">glow · interactive only</div>
            </div>
          </Panel>
        </div>
      </div>
    </Section>
  )
}

function ComponentsSection() {
  const [q, setQ] = useState('orbit')
  const [f, setF] = useState('all')
  return (
    <Section id="components" className="border-t border-border">
      <SectionHeader index="04" eyebrow="Components" title="Small, strict, reusable." description="Every component ships its states. Hover is a hint, focus is a guarantee, disabled is obvious." />
      <div className="mt-14 grid gap-6 lg:grid-cols-12">
        <Panel label="Buttons — variants" className="lg:col-span-7">
          <div className="flex flex-wrap items-center gap-3">
            <Button iconEnd={<ArrowRight />}>Explore projects</Button>
            <Button variant="secondary">Read the docs</Button>
            <Button variant="ghost">Changelog</Button>
            <IconButton label="Subscribe via RSS" variant="secondary" icon={<Rss />} />
          </div>
          <span className="font-mono text-micro uppercase text-fg-subtle">States</span>
          <div className="flex flex-wrap items-center gap-3">
            <Button loading>Deploying</Button>
            <Button disabled>Disabled</Button>
            <Button variant="secondary" size="sm">Small</Button>
            <Button size="lg" iconStart={<Sparkles className="size-4" />}>Large</Button>
          </div>
        </Panel>
        <Panel label="Links" className="lg:col-span-5">
          <p className="text-body text-fg-soft">
            Read the <TextLink href="#a11y">contribution guide</TextLink> or browse the{' '}
            <TextLink href="https://github.com/ThanhNguyxnOrg" external>GitHub organization</TextLink>.
          </p>
          <TextLink href="#type" tone="muted">Muted link — for secondary navigation</TextLink>
        </Panel>
        <Panel label="Badges · tags · meta · status" className="lg:col-span-7">
          <div className="flex flex-wrap gap-2">
            <Badge>Neutral</Badge><Badge tone="primary">Dev tools</Badge><Badge tone="secondary">Frontend</Badge><Badge tone="contrast">Experiments</Badge><Badge tone="highlight">New</Badge>
          </div>
          <div className="flex flex-wrap gap-1.5"><Tag>typescript</Tag><Tag>rust</Tag><Tag>three.js</Tag><Tag>astro</Tag></div>
          <MetaLabel index="TN-014">Experiments · 2025</MetaLabel>
          <div className="flex flex-wrap gap-x-6 gap-y-3">
            <StatusIndicator status="active" pulse /><StatusIndicator status="beta" /><StatusIndicator status="experimental" /><StatusIndicator status="archived" />
          </div>
        </Panel>
        <Panel label="Search & filter" className="lg:col-span-5">
          <SearchField label="Search projects" value={q} onValueChange={setQ} placeholder="Name, tech, keyword…" hint="Matches titles, summaries and technologies." />
          <SearchField label="With error" value="" onValueChange={() => {}} placeholder="Repository URL" error="Enter a valid github.com URL." />
          <FilterGroup label="Category" value={f} onChange={setF} options={[{ value: 'all', label: 'All', count: 24 }, { value: 'tools', label: 'Dev tools', count: 9 }, { value: 'fe', label: 'Frontend', count: 7 }, { value: 'exp', label: 'Experiments', count: 8 }]} />
        </Panel>
        <Panel label="Empty" className="lg:col-span-4">
          <EmptyState className="py-10" icon={<SearchX />} title="No matches" description="Try a broader term or reset filters." action={<Button variant="secondary" size="sm">Reset filters</Button>} />
        </Panel>
        <Panel label="Error" className="lg:col-span-4">
          <ErrorState title="Couldn't load repositories" description="GitHub rate limit reached. Data will refresh in 12 minutes." action={<Button variant="secondary" size="sm">Retry now</Button>} />
        </Panel>
        <Panel label="Loading" className="lg:col-span-4">
          <ProjectCardSkeleton />
        </Panel>
      </div>
    </Section>
  )
}

const filters = ['All', 'Dev tools', 'Frontend', 'Infra', 'Experiments']

function ProjectsSection() {
  const [query, setQuery] = useState('')
  const [cat, setCat] = useState('All')
  const [featured, ...rest] = projects
  const results = useMemo(() => {
    const q = query.trim().toLowerCase()
    return rest.filter(
      (p) =>
        (cat === 'All' || p.category === cat) &&
        (!q || [p.title, p.summary, ...p.technologies].join(' ').toLowerCase().includes(q)),
    )
  }, [query, cat, rest])

  return (
    <Section id="projects" className="border-t border-border">
      <SectionHeader index="05" eyebrow="Project showcase" title="One spotlight, then the index." description="Featured layouts carry the story; cards carry the catalogue. Never put both at the same size in one row." />
      <Reveal className="mt-14">
        <div data-reveal>
          <FeaturedProject project={featured} highlights={[{ value: '2.4k', label: 'Stars' }, { value: '38', label: 'Contributors' }, { value: '<1s', label: 'Cold start' }]} />
        </div>
      </Reveal>
      <div className="mt-16 flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
        <FilterGroup label="Filter by category" value={cat} onChange={setCat} options={filters.map((c) => ({ value: c, label: c, count: c === 'All' ? rest.length : rest.filter((p) => p.category === c).length }))} />
        <SearchField className="md:w-72" label="Search projects" hideLabel value={query} onValueChange={setQuery} placeholder="Search projects…" />
      </div>
      <p className="sr-only" aria-live="polite">{results.length} projects shown</p>
      {results.length ? (
        <Reveal key={cat + query} className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {results.map((p) => (
            <div data-reveal key={p.id}><ProjectCard project={p} /></div>
          ))}
          <div data-reveal className="flex flex-col justify-between gap-6 rounded-lg border border-dashed border-border-strong p-6">
            <MetaLabel index="TN-???">Next</MetaLabel>
            <p className="font-display text-display-md font-semibold text-fg-soft">Something is always in the lab.</p>
            <TextLink href="https://github.com/ThanhNguyxnOrg" external>Watch the org</TextLink>
          </div>
        </Reveal>
      ) : (
        <EmptyState className="mt-8" icon={<SearchX />} title="Nothing in the lab matches that" description={`No projects for "${query}" in ${cat}.`} action={<Button variant="secondary" size="sm" onClick={() => { setQuery(''); setCat('All') }}>Clear search & filters</Button>} />
      )}
    </Section>
  )
}

function MotionSection() {
  const tokens = [
    ['instant', '120ms', 'Press feedback, color'],
    ['fast', '200ms', 'Hover, focus, toggles'],
    ['base', '320ms', 'Panels, small reveals'],
    ['slow', '600ms', 'Scroll entrances'],
    ['epic', '1000ms', 'Hero sequence only'],
  ]
  return (
    <Section id="motion" className="border-t border-border">
      <SectionHeader index="06" eyebrow="Motion" title="Motion explains arrival. It never performs." description="GSAP owns choreography. CSS owns hover. Everything is final and readable with motion off." />
      <div className="mt-14 grid gap-6 lg:grid-cols-12">
        <div className="lg:col-span-7"><MotionDemo /></div>
        <div className="flex flex-col gap-6 lg:col-span-5">
          <Panel label="Duration tokens">
            <dl className="flex flex-col divide-y divide-border">
              {tokens.map(([k, v, use]) => (
                <div key={k} className="grid grid-cols-[5rem_4.5rem_1fr] gap-3 py-2.5">
                  <dt className="font-mono text-label text-primary-text">{k}</dt>
                  <dd className="font-mono text-label text-fg">{v}</dd>
                  <dd className="text-body-sm text-fg-subtle">{use}</dd>
                </div>
              ))}
            </dl>
          </Panel>
          <Panel label="Hover feedback — CSS only">
            <div className="flex flex-wrap gap-3">
              <div className="rounded-md border border-border-strong px-4 py-3 font-mono text-label text-fg-muted transition-ui hover:-translate-y-1 hover:border-secondary hover:text-secondary">lift · 4px</div>
              <div className="rounded-md border border-border-strong px-4 py-3 font-mono text-label text-fg-muted transition-ui hover:shadow-glow-primary">glow · CTA only</div>
              <div className="group/arrow inline-flex items-center gap-2 rounded-md border border-border-strong px-4 py-3 font-mono text-label text-fg-muted">nudge <ArrowRight aria-hidden className="size-4 transition-ui group-hover/arrow:translate-x-1" /></div>
            </div>
          </Panel>
        </div>
      </div>
    </Section>
  )
}

function ResponsiveSection() {
  const bps = [
    { name: 'base', px: '0', frame: 'w-24', cols: 1, note: 'Single column · drawer nav · filters scroll' },
    { name: 'md', px: '768', frame: 'w-40', cols: 2, note: 'Inline nav · 2-up cards · 8-col grid' },
    { name: 'lg', px: '1024', frame: 'w-64', cols: 3, note: '12-col grid · asymmetric splits · 3-up cards' },
  ]
  return (
    <Section id="responsive" className="border-t border-border">
      <SectionHeader index="07" eyebrow="Responsive" title="Recomposed, not shrunk." description="Each breakpoint changes the composition: navigation pattern, column count, and the order of media and copy." />
      <div className="mt-14 grid gap-6 md:grid-cols-3">
        {bps.map((b) => (
          <div key={b.name} className="flex flex-col gap-5 rounded-lg border border-border bg-surface p-6">
            <div className="flex h-56 items-end justify-center rounded-md bg-bg bg-blueprint p-4">
              <div className={clsx('flex h-full flex-col gap-1.5 rounded-sm border border-border-strong bg-surface p-2', b.frame)}>
                <div className="flex h-3 items-center justify-between"><span className="h-1.5 w-6 rounded-xs bg-fg-subtle" />{b.cols === 1 ? <span className="h-1.5 w-2 bg-fg-subtle" /> : <span className="h-1.5 w-10 rounded-xs bg-border-strong" />}</div>
                <div className="h-6 rounded-xs bg-primary/40" />
                <div className={clsx('grid flex-1 gap-1.5', b.cols === 1 ? 'grid-cols-1' : b.cols === 2 ? 'grid-cols-2' : 'grid-cols-3')}>
                  {Array.from({ length: b.cols * 2 }).map((_, i) => <div key={i} className="rounded-xs bg-surface-raised ring-1 ring-border ring-inset" />)}
                </div>
              </div>
            </div>
            <div className="flex items-baseline justify-between"><span className="font-display text-title font-semibold">{b.name}</span><span className="font-mono text-label text-fg-muted">≥ {b.px}px</span></div>
            <p className="text-body-sm text-fg-muted">{b.note}</p>
          </div>
        ))}
      </div>
    </Section>
  )
}

function A11ySection() {
  const rules = [
    ['Focus is always visible', '2px cyan outline, 3px offset, on every interactive element — never removed.'],
    ['44px touch targets', 'Icon buttons and nav controls are 44×44 at md. Inline links get 36px row height in lists.'],
    ['Never color alone', 'Status = shape + label + color. Links are underlined. Errors carry an icon and text.'],
    ['Motion is optional', 'Content renders final by default; GSAP animates from offsets only when motion is allowed.'],
    ['Semantic first', 'nav, header, article, dl, ol, time. One h1 per page; SectionHeader defaults to h2.'],
    ['Announce changes', 'Filtered result counts use aria-live; errors use role="alert"; toggles use aria-pressed.'],
  ]
  return (
    <Section id="a11y" className="border-t border-border">
      <SectionHeader index="08" eyebrow="Accessibility" title="Accessible by construction." description="Press Tab anywhere on this page — every control shows the same cyan focus ring." />
      <div className="mt-14 grid gap-px overflow-hidden rounded-lg border border-border bg-border md:grid-cols-2 lg:grid-cols-3">
        {rules.map(([t, d], i) => (
          <div key={t} className="flex flex-col gap-3 bg-bg p-6">
            <span className="font-mono text-label text-primary-text">A-{String(i + 1).padStart(2, '0')}</span>
            <p className="font-display text-title font-semibold">{t}</p>
            <p className="text-body-sm text-fg-muted">{d}</p>
          </div>
        ))}
      </div>
      <div className="mt-6 grid gap-6 md:grid-cols-2">
        <Panel label="Do">
          <div className="flex items-start gap-3"><Check aria-hidden className="mt-0.5 size-5 text-success" /><div className="flex flex-col gap-3"><StatusIndicator status="experimental" /><p className="text-body-sm text-fg-muted">Shape + label + color communicate status.</p></div></div>
          <div className="flex items-center gap-3"><Keyboard aria-hidden className="size-5 text-secondary" /><span className="text-body-sm text-fg-muted">Tab to this button:</span><Button size="sm" variant="secondary">Focus me</Button></div>
        </Panel>
        <Panel label="Don't">
          <div className="flex items-start gap-3"><X aria-hidden className="mt-0.5 size-5 text-error" /><div className="flex flex-col gap-3"><span aria-hidden className="size-3 rounded-full bg-warning" /><p className="text-body-sm text-fg-muted">A lone colored dot means nothing to colorblind or screen-reader users.</p></div></div>
          <div className="flex items-start gap-3"><X aria-hidden className="mt-0.5 size-5 text-error" /><p className="text-body-sm text-fg-muted">Fg-subtle for paragraphs, lime text on light surfaces, or glow on every card.</p></div>
        </Panel>
      </div>
    </Section>
  )
}

export default function Playground() {
  return (
    <div className="min-h-screen bg-bg text-fg">
      <SiteNav items={nav} currentHref="#components" action={<Button size="sm" href="https://github.com/ThanhNguyxnOrg" variant="secondary" iconStart={<GitHubMark className="size-4" />}>GitHub</Button>} />
      <main>
        {/* Brand overview */}
        <div className="relative overflow-hidden border-b border-border">
          <div aria-hidden className="absolute inset-0 bg-aurora" />
          <div aria-hidden className="absolute inset-0 bg-blueprint [mask-image:radial-gradient(ellipse_at_top_right,black,transparent_70%)]" />
          <Container className="relative grid gap-12 py-20 md:py-32 lg:grid-cols-12">
            <Reveal trigger="mount" stagger="loose" className="flex flex-col gap-8 lg:col-span-8">
              <div data-reveal><MetaLabel index="v0.1">TNORG Creative System</MetaLabel></div>
              <p data-reveal role="heading" aria-level={1} className="font-display text-display-2xl font-semibold text-balance">
                Independent lab.<br /><span className="text-gradient-brand">Built in the open.</span>
              </p>
              <p data-reveal className="max-w-reading text-body-lg text-fg-muted">
                The visual and interaction system for ThanhNguyxnOrg — open-source software, developer tools and experiments. Expressive where it matters, strict everywhere else.
              </p>
              <div data-reveal className="flex flex-wrap gap-3">
                <Button href="#components" size="lg" iconEnd={<ArrowRight />}>Browse components</Button>
                <Button href="#color" size="lg" variant="secondary">Foundations</Button>
              </div>
            </Reveal>
            <div className="flex flex-col justify-end gap-6 lg:col-span-4">
              <LogoMark className="size-28 md:size-36" title="TNORG mark" />
              <ul className="flex flex-col divide-y divide-border border-y border-border">
                {[['/', 'Path — every project is a route into the lab'], ['[ ]', 'Bracket — open source, open frame'], ['■', 'Node — the moment something ships']].map(([g, t]) => (
                  <li key={g} className="flex gap-4 py-3"><span className="w-8 font-mono text-label text-highlight">{g}</span><span className="text-body-sm text-fg-muted">{t}</span></li>
                ))}
              </ul>
            </div>
          </Container>
          <Container className="relative pb-16">
            <StatGroup>
              <Stat value="5" label="Brand colors" accent="primary" detail="1 canvas · 2 accents · 2 sparks" />
              <Stat value="3" label="Typefaces" accent="secondary" detail="Display · UI · Mono" />
              <Stat value="18" label="Components" detail="Each with full state set" />
              <Stat value="AA" label="Contrast floor" accent="highlight" detail="All text tokens on bg" />
            </StatGroup>
          </Container>
        </div>

        <ColorSection />
        <TypeSection />
        <LayoutSection />
        <ComponentsSection />
        <ProjectsSection />
        <MotionSection />
        <ResponsiveSection />
        <A11ySection />

        <Section id="timeline" className="border-t border-border">
          <div className="grid gap-12 lg:grid-cols-12">
            <SectionHeader className="lg:col-span-5 lg:grid-cols-1" index="09" eyebrow="Timeline" title="Lab log." description="Timeline items document releases and milestones. The lime node marks now." />
            <Timeline className="lg:col-span-7">
              <TimelineItem current date="2025 · Q3" title="Creative System v0.1" description="Tokens, components and motion rules published as a Make Kit." tags={['tailwind v4', 'gsap']} />
              <TimelineItem date="2025 · Q1" title="Lattice UI enters beta" description="Headless primitives extracted from three internal projects." tags={['react', 'astro']} />
              <TimelineItem date="2024 · Q2" title="Orbit CLI 1.0" description="First stable release with reproducible build pipelines." />
            </Timeline>
          </div>
        </Section>

        <Container className="pb-24">
          <CTASection
            eyebrow="Contribute"
            title={<>Have an idea worth <span className="text-gradient-brand">shipping?</span></>}
            description="Every TNORG project is open. Pick an issue, propose an experiment, or fork the system."
            actions={<><Button href="https://github.com/ThanhNguyxnOrg" size="lg" iconStart={<GitHubMark className="size-4" />}>Start on GitHub</Button><Button href="mailto:hello@example.com" size="lg" variant="ghost" iconStart={<Mail className="size-4" />}>Email the lab</Button></>}
          />
        </Container>
      </main>
      <SiteFooter
        tagline="An independent technology lab building open-source software, developer tools and experimental digital products."
        legal="© 2025 ThanhNguyxnOrg · MIT"
        socials={[{ label: 'GitHub', href: 'https://github.com/ThanhNguyxnOrg', icon: <GitHubMark /> }, { label: 'RSS', href: '#', icon: <Rss /> }]}
        columns={[
          { title: 'System', links: [{ label: 'Color', href: '#color' }, { label: 'Typography', href: '#type' }, { label: 'Layout', href: '#layout' }] },
          { title: 'Build', links: [{ label: 'Components', href: '#components' }, { label: 'Motion', href: '#motion' }, { label: 'Accessibility', href: '#a11y' }] },
          { title: 'Lab', links: [{ label: 'GitHub', href: 'https://github.com/ThanhNguyxnOrg', external: true }, { label: 'Projects', href: '#projects' }] },
        ]}
      />
    </div>
  )
}
