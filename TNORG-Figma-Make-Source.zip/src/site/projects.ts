import { z } from 'zod'

/**
 * Project data boundary.
 * Today: hand-edited seed records below, validated at module load.
 * Later: a GitHub/npm sync job can emit the same shape (e.g. projects.json)
 * and pass it through `parseProjects` — no UI changes required.
 * Nothing on this page is synchronized automatically yet.
 */
export const projectSchema = z.object({
  slug: z.string().regex(/^[a-z0-9-]+$/),
  title: z.string().min(1),
  summary: z.string().min(1),
  /** false = placeholder copy; UI shows a "details pending" note. */
  summaryVerified: z.boolean(),
  category: z.string().min(1),
  repoUrl: z.url().nullable(),
  demoUrl: z.url().nullable(),
  tags: z.array(z.string()),
  status: z.enum(['active', 'beta', 'experimental', 'archived']).optional(),
  /** Screenshot path/URL. Omit to show the replaceable placeholder. */
  image: z.string().optional(),
  featured: z.boolean().default(false),
  /** Lower = earlier in default sort. */
  order: z.number().int(),
  /** Visual identity for placeholders (design-system accent + glyph). */
  accent: z.enum(['primary', 'secondary', 'highlight', 'contrast']),
  pattern: z.enum(['orbit', 'grid', 'stack', 'wave']),
})

export type ProjectRecord = z.infer<typeof projectSchema>

const PENDING = 'Description pending verification. Edit this record in src/site/projects.ts.'

const seed: z.input<typeof projectSchema>[] = [
  {
    slug: 'lagvex',
    title: 'Lagvex',
    summary: 'An open-source Windows gaming network-routing and ping-optimization project.',
    summaryVerified: true,
    category: 'Networking',
    repoUrl: null, // TODO: verify repository URL
    demoUrl: null,
    tags: ['windows', 'networking', 'gaming'],
    featured: true,
    order: 1,
    accent: 'secondary',
    pattern: 'orbit',
  },
  {
    slug: 'locsight',
    title: 'Locsight',
    summary: PENDING,
    summaryVerified: false,
    category: 'Lab project',
    repoUrl: null, // TODO: verify repository URL
    demoUrl: null,
    tags: [],
    featured: true,
    order: 2,
    accent: 'primary',
    pattern: 'grid',
  },
  {
    slug: 'layoutlingua',
    title: 'LayoutLingua',
    summary: PENDING,
    summaryVerified: false,
    category: 'Lab project',
    repoUrl: null, // TODO: verify repository URL
    demoUrl: null,
    tags: [],
    featured: true,
    order: 3,
    accent: 'contrast',
    pattern: 'stack',
  },
]

export function parseProjects(input: unknown): ProjectRecord[] {
  return z.array(projectSchema).parse(input).sort((a, b) => a.order - b.order)
}

export const projects = parseProjects(seed)
export const featuredProjects = projects.filter((p) => p.featured)
export const categories = [...new Set(projects.map((p) => p.category))]
export const allTags = [...new Set(projects.flatMap((p) => p.tags))].sort()

/** Stable display index, e.g. TN-01 (position in default order, not a release number). */
export const projectCode = (p: ProjectRecord) => `TN-${String(projects.indexOf(p) + 1).padStart(2, '0')}`
