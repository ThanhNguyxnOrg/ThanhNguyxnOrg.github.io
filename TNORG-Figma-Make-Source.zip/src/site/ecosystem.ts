import { links } from './config'
import { projects } from './projects'

/** Ecosystem resources. Derived from config + project records — no counts, no live data. */
export type Resource = {
  kind: 'Organization' | 'Repository' | 'Package' | 'Resource'
  label: string
  description: string
  url: string | null
}

export const resources: Resource[] = [
  {
    kind: 'Organization',
    label: 'ThanhNguyxnOrg on GitHub',
    description: 'Home of every TNORG repository, issue tracker and discussion.',
    url: links.github.url,
  },
  ...projects.map<Resource>((p) => ({
    kind: 'Repository',
    label: p.title,
    description: p.summaryVerified ? p.summary : 'Repository details pending verification.',
    url: p.repoUrl,
  })),
  {
    kind: 'Package',
    label: 'Published packages',
    description: 'No packages listed yet. Add verified npm packages in src/site/ecosystem.ts.',
    url: links.npm.url,
  },
]
