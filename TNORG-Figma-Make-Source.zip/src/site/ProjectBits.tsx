import clsx from 'clsx'
import { ArrowUpRight, ImageOff } from 'lucide-react'
import { Badge, Button, GitHubMark, ProjectGlyph } from '../index'
import type { ProjectRecord } from './projects'

/**
 * Project visual. Uses `project.image` when provided; otherwise a clearly
 * labelled, replaceable placeholder (never stock imagery posing as a UI).
 */
export function ProjectVisual({ project, className, label = true }: { project: ProjectRecord; className?: string; label?: boolean }) {
  if (project.image) {
    return <img src={project.image} alt={`${project.title} screenshot`} loading="lazy" className={clsx('object-cover', className)} />
  }
  return (
    <div className={clsx('relative', className)}>
      <ProjectGlyph pattern={project.pattern} accent={project.accent} className="absolute inset-0" />
      {label && (
        <span className="absolute bottom-3 left-3 inline-flex items-center gap-1.5 rounded-xs bg-bg/80 px-2 py-1 font-mono text-micro uppercase text-fg-subtle backdrop-blur">
          <ImageOff aria-hidden className="size-3" /> Screenshot placeholder
        </span>
      )}
    </div>
  )
}

export function PendingNote({ project }: { project: ProjectRecord }) {
  if (project.summaryVerified) return null
  return <Badge tone="neutral" className="border-dashed">Details pending</Badge>
}

/** Repo + demo actions. Unverified URLs render as inert text, not links. */
export function ProjectActions({ project, size = 'md' }: { project: ProjectRecord; size?: 'sm' | 'md' }) {
  return (
    <div className="flex flex-wrap items-center gap-3">
      {project.repoUrl ? (
        <Button size={size} href={project.repoUrl} target="_blank" rel="noopener noreferrer" iconStart={<GitHubMark className="size-4" />}>
          Repository
        </Button>
      ) : (
        <span className="inline-flex h-9 items-center gap-2 rounded-sm border border-dashed border-border-strong px-3 font-mono text-label uppercase text-fg-subtle">
          <GitHubMark className="size-3.5" /> Repo link pending
        </span>
      )}
      {project.demoUrl && (
        <Button size={size} variant="secondary" href={project.demoUrl} target="_blank" rel="noopener noreferrer" iconEnd={<ArrowUpRight />}>
          Live demo
        </Button>
      )}
    </div>
  )
}
