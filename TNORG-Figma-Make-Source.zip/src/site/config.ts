/**
 * Single source for site metadata and external URLs.
 * `url: null` = destination not verified yet. The UI renders those as
 * "link pending" text, never as a working link. Fill in once confirmed.
 */
export type ExternalLink = { label: string; url: string | null }

export const site = {
  name: 'TNORG',
  fullName: 'ThanhNguyxnOrg',
  domain: 'ThanhNguyxnOrg.github.io',
  tagline: 'Open-source software, developer tools, and experiments built with curiosity and engineering craft.',
} as const

export const links = {
  /** Derived from the GitHub Pages domain ThanhNguyxnOrg.github.io. */
  github: { label: 'GitHub', url: 'https://github.com/ThanhNguyxnOrg' },
  /** Not verified — add when a contact channel is confirmed. */
  contact: { label: 'Contact', url: null },
  /** Not verified — add if packages are published. */
  npm: { label: 'npm', url: null },
} satisfies Record<string, ExternalLink>

export const nav = [
  { label: 'Projects', href: '#projects' },
  { label: 'About', href: '#about' },
  { label: 'Ecosystem', href: '#ecosystem' },
]
