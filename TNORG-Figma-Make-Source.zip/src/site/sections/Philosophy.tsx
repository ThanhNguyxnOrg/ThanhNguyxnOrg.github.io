import clsx from 'clsx'
import { Reveal, SectionHeader } from '../../index'

const principles = [
  { verb: 'Explore', line: 'Ideas start as experiments.', body: 'Small prototypes test whether an idea deserves to become a tool.', tone: 'text-contrast' },
  { verb: 'Build', line: 'Useful beats impressive.', body: 'Projects aim at real problems and ship as working software.', tone: 'text-primary-text' },
  { verb: 'Iterate', line: 'Engineering plus feedback.', body: 'Releases improve through testing, issues and honest critique.', tone: 'text-secondary' },
  { verb: 'Share', line: 'Open by default.', body: 'Code, tools and learnings go back to the community.', tone: 'text-highlight' },
]

/** Principles as a loop (Explore → Share → Explore), not a dated history. */
export default function Philosophy() {
  return (
    <section id="about" aria-labelledby="about-title" className="scroll-mt-20 border-t border-border bg-surface/40">
      <div className="mx-auto w-full max-w-page px-5 py-20 md:px-8 md:py-28 lg:px-12">
        <SectionHeader index="03" eyebrow="How the lab works" title={<span id="about-title">Four verbs, on repeat.</span>} description="TNORG is not tied to one product category. These are the principles every project currently follows." />
        <Reveal as="ol" stagger="base" className="mt-14 grid border-t border-border md:grid-cols-2 lg:grid-cols-4">
          {principles.map((p, i) => (
            <li data-reveal key={p.verb} className={clsx('relative flex flex-col gap-4 border-b border-border py-8 md:px-6 lg:border-b-0', i % 2 === 0 && 'md:border-r lg:border-r', i === 1 && 'lg:border-r', i === 3 && 'md:border-r-0', i === 0 && 'md:pl-0')}>
              <span className="font-mono text-label text-fg-subtle">0{i + 1} {i === 3 ? '↺ 01' : '→'}</span>
              <span className={clsx('font-display text-display-lg font-bold', p.tone)}>{p.verb}</span>
              <span className="font-display text-title font-semibold text-fg">{p.line}</span>
              <span className="text-body-sm text-fg-muted">{p.body}</span>
            </li>
          ))}
        </Reveal>
      </div>
    </section>
  )
}
