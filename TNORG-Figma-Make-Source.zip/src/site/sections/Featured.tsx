import clsx from 'clsx'
import { MetaLabel, Reveal, SectionHeader, StatusIndicator, Tag, Badge } from '../../index'
import { featuredProjects, projectCode, type ProjectRecord } from '../projects'
import { PendingNote, ProjectActions, ProjectVisual } from '../ProjectBits'

function Tags({ p }: { p: ProjectRecord }) {
  if (!p.tags.length) return null
  return (
    <ul className="flex flex-wrap gap-1.5" aria-label="Tags">
      {p.tags.map((t) => <li key={t}><Tag>{t}</Tag></li>)}
    </ul>
  )
}

function Meta({ p }: { p: ProjectRecord }) {
  return (
    <div className="flex flex-wrap items-center gap-3">
      <MetaLabel index={projectCode(p)}>{p.category}</MetaLabel>
      {p.status && <StatusIndicator status={p.status} />}
      <PendingNote project={p} />
    </div>
  )
}

/** Lead: oversized, 7/5, media bleeds to the edge of the frame. */
function Lead({ p }: { p: ProjectRecord }) {
  return (
    <article className="grid overflow-hidden rounded-xl border border-border bg-surface lg:grid-cols-12">
      <ProjectVisual project={p} className="min-h-72 md:min-h-96 lg:col-span-7" />
      <div className="flex flex-col gap-6 p-6 md:p-10 lg:col-span-5">
        <Badge tone="secondary" className="self-start">Featured</Badge>
        <Meta p={p} />
        <h3 className="font-display text-display-xl font-bold text-fg">{p.title}</h3>
        <p className="max-w-measure text-body-lg text-fg-soft">{p.summary}</p>
        <Tags p={p} />
        <div className="mt-auto pt-2"><ProjectActions project={p} /></div>
      </div>
    </article>
  )
}

/** Poster: tall, title-dominant, media as a framed inset. */
function Poster({ p }: { p: ProjectRecord }) {
  return (
    <article className="relative flex h-full flex-col gap-6 overflow-hidden rounded-xl border border-border bg-surface p-6 md:p-8">
      <Meta p={p} />
      <h3 className="font-display text-display-lg font-bold text-fg">{p.title}</h3>
      <ProjectVisual project={p} className="aspect-[4/3] overflow-hidden rounded-lg border border-border" />
      <p className="text-body text-fg-muted">{p.summary}</p>
      <Tags p={p} />
      <div className="mt-auto"><ProjectActions project={p} size="sm" /></div>
    </article>
  )
}

/** Strip: wide, typographic, media as a narrow band on the right. */
function Strip({ p }: { p: ProjectRecord }) {
  return (
    <article className="grid h-full overflow-hidden rounded-xl border border-border bg-surface md:grid-cols-5">
      <div className="flex flex-col gap-5 p-6 md:col-span-3 md:p-8">
        <Meta p={p} />
        <h3 className="font-display text-display-lg font-bold text-fg">{p.title}</h3>
        <p className="text-body text-fg-muted">{p.summary}</p>
        <Tags p={p} />
        <div className="mt-auto pt-2"><ProjectActions project={p} size="sm" /></div>
      </div>
      <ProjectVisual project={p} className="order-first min-h-48 md:order-none md:col-span-2" />
    </article>
  )
}

export default function Featured() {
  const [lead, ...rest] = featuredProjects
  if (!lead) return null
  return (
    <section id="projects" aria-labelledby="featured-title" className="scroll-mt-20">
      <div className="mx-auto w-full max-w-page px-5 py-20 md:px-8 md:py-28 lg:px-12">
        <SectionHeader
          index="01"
          eyebrow="Featured projects"
          title={<span id="featured-title">Things leaving the lab.</span>}
          description="A rotating selection of projects. Every record here is editable seed data — no stats, no invented claims."
        />
        <Reveal className="mt-14 flex flex-col gap-6" stagger="loose">
          <div data-reveal><Lead p={lead} /></div>
          {rest.length > 0 && (
            <div className="grid gap-6 lg:grid-cols-12">
              {rest.map((p, i) => (
                <div data-reveal key={p.slug} className={clsx(i % 2 === 0 ? 'lg:col-span-5' : 'lg:col-span-7')}>
                  {i % 2 === 0 ? <Poster p={p} /> : <Strip p={p} />}
                </div>
              ))}
            </div>
          )}
        </Reveal>
      </div>
    </section>
  )
}
