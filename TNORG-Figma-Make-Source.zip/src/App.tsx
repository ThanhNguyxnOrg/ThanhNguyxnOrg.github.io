import { Button, Container, CTASection, GitHubMark, SiteFooter, SiteNav } from './index'
import { links, nav, site } from './site/config'
import Hero from './site/sections/Hero'
import Featured from './site/sections/Featured'
import Explorer from './site/sections/Explorer'
import Philosophy from './site/sections/Philosophy'
import Ecosystem from './site/sections/Ecosystem'


export default function App() {
  return (
    <div className="min-h-screen bg-bg text-fg">
      <SiteNav
        items={nav}
        action={
          <Button size="sm" variant="secondary" href={links.github.url} target="_blank" rel="noopener noreferrer" iconStart={<GitHubMark className="size-4" />}>
            GitHub
          </Button>
        }
      />
      <main>
        <Hero />
        <Featured />
        <Explorer />
        <Philosophy />
        <Ecosystem />
        <Container className="py-24">
          <CTASection
            eyebrow="Join the loop"
            title={<>Use it. Fork it. <span className="text-gradient-brand">Make it better.</span></>}
            description="Every TNORG project is built in the open. Star a repository, open an issue, or follow the organization to see what leaves the lab next."
            actions={
              <>
                <Button size="lg" href={links.github.url} target="_blank" rel="noopener noreferrer" iconStart={<GitHubMark className="size-4" />}>Follow on GitHub</Button>
                <Button size="lg" variant="ghost" href="#archive">Browse the index</Button>
              </>
            }
          />
        </Container>
      </main>
      <SiteFooter
        tagline={`${site.fullName} — ${site.tagline}`}
        legal={`© ${new Date().getFullYear()} ${site.fullName}`}
        socials={[{ label: 'GitHub', href: links.github.url, icon: <GitHubMark /> }]}
        columns={[
          { title: 'Site', links: nav },
          { title: 'Explore', links: [{ label: 'Featured', href: '#projects' }, { label: 'Project index', href: '#archive' }] },
          { title: 'Elsewhere', links: [{ label: 'GitHub', href: links.github.url, external: true }] },
        ]}
      />
    </div>
  )
}
