import clsx from 'clsx'

/**
 * TNORG mark: an open bracket frame (open source) cut by a forward slash
 * (the lab's "/" path separator) with a lime node — the moment a thing ships.
 */
export function LogoMark({ className, title = 'TNORG' }: { className?: string; title?: string }) {
  return (
    <svg viewBox="0 0 32 32" role="img" aria-label={title} className={clsx('size-8 shrink-0', className)}>
      <path d="M11 5H6v22h5" fill="none" stroke="var(--color-primary)" strokeWidth="2.5" strokeLinecap="square" />
      <path d="M21 5h5v22h-5" fill="none" stroke="var(--color-secondary)" strokeWidth="2.5" strokeLinecap="square" />
      <path d="M19.5 8.5 12.5 23.5" stroke="var(--color-fg)" strokeWidth="2.5" strokeLinecap="square" />
      <rect x="19" y="20" width="4" height="4" fill="var(--color-highlight)" />
    </svg>
  )
}

export default function Logo({ className, showDescriptor = false }: { className?: string; showDescriptor?: boolean }) {
  return (
    <span className={clsx('inline-flex items-center gap-2.5', className)}>
      <LogoMark title="" />
      <span className="flex flex-col leading-none">
        <span className="font-display text-title font-bold tracking-tight text-fg">TNORG</span>
        {showDescriptor && <span className="mt-1 font-mono text-micro uppercase text-fg-subtle">ThanhNguyxnOrg</span>}
      </span>
      <span className="sr-only">TNORG home</span>
    </span>
  )
}
