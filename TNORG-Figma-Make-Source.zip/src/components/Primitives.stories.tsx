import { ArrowRight, Rss } from 'lucide-react'
import { Badge, Button, IconButton, MetaLabel, StatusIndicator, Tag, TextLink } from '../index'

export default { title: 'TNORG/Primitives' }

export const Buttons = () => (
  <div className="flex flex-wrap items-center gap-3 bg-bg p-8">
    <Button iconEnd={<ArrowRight />}>Primary</Button>
    <Button variant="secondary">Secondary</Button>
    <Button variant="ghost">Ghost</Button>
    <IconButton label="RSS" variant="secondary" icon={<Rss />} />
    <Button loading>Loading</Button>
    <Button disabled>Disabled</Button>
  </div>
)

export const Labels = () => (
  <div className="flex flex-col gap-4 bg-bg p-8">
    <div className="flex gap-2"><Badge tone="primary">Dev tools</Badge><Badge tone="secondary">Frontend</Badge><Badge tone="highlight">New</Badge></div>
    <div className="flex gap-1.5"><Tag>typescript</Tag><Tag>rust</Tag></div>
    <MetaLabel index="TN-001">Dev tools</MetaLabel>
    <div className="flex gap-6"><StatusIndicator status="active" /><StatusIndicator status="beta" /><StatusIndicator status="experimental" /><StatusIndicator status="archived" /></div>
    <TextLink href="#" external>External link</TextLink>
  </div>
)
