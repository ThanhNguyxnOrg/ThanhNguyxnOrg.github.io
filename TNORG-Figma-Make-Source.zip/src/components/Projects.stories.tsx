import { FeaturedProject, ProjectCard, ProjectCardSkeleton } from '../index'
import { projects } from '../showcase/data'

export default { title: 'TNORG/Projects' }

export const Card = () => (
  <div className="grid max-w-page gap-6 bg-bg p-8 sm:grid-cols-2 lg:grid-cols-3">
    <ProjectCard project={projects[1]} />
    <ProjectCard project={projects[2]} />
    <ProjectCardSkeleton />
  </div>
)

export const Featured = () => (
  <div className="bg-bg p-8"><FeaturedProject project={projects[0]} highlights={[{ value: '2.4k', label: 'Stars' }, { value: '38', label: 'Contributors' }]} /></div>
)
