# Icons

**Family: `lucide-react` (v1.55) only.** `@phosphor-icons/react` is installed but not used —
mixing families breaks stroke consistency.

## Import
```tsx
import { ArrowRight, ArrowUpRight, Search } from 'lucide-react'
```
PascalCase names. lucide 1.x renamed legacy aliases: use `LoaderCircle` (not `Loader2`),
`CodeXml` (not `Code2`), `CircleAlert`, `TriangleAlert`, `CircleCheck`.

## Brand marks
lucide 1.x ships **no brand icons** (`Github`, `Twitter`, `Linkedin` do not exist).
Use the kit's `GitHubMark`; add other marks to `src/components/BrandIcons.tsx` as
`aria-hidden` SVGs using `currentColor`.

## Verify before use
```sh
grep -q "declare const RotateCcw:" node_modules/lucide-react/dist/lucide-react.d.ts && echo ok
grep -o "declare const [A-Z][A-Za-z0-9]*:" node_modules/lucide-react/dist/lucide-react.d.ts | grep -i arrow
```

## Sizing & color
- `size-4` (16) in buttons, links, tags; `size-5` (20) in icon buttons, alerts; `size-6` in empty states.
- Default stroke (2). Color inherits `currentColor`; tint with semantic text tokens only.
- Decorative icons: `aria-hidden`. Meaningful standalone icons live inside an `IconButton` (label required).

## Sanctioned glyphs
| Meaning | Icon |
|---|---|
| Internal forward action | `ArrowRight` (iconEnd, nudges on hover) |
| External link | `ArrowUpRight` (automatic in `TextLink external`) |
| Search / clear | `Search` / `X` |
| Menu | `Menu` / `X` |
| Loading | `LoaderCircle` (automatic in `Button loading`) |
| Error / empty | `CircleAlert` / `Inbox`, `SearchX` |
| Success | `Check` |
