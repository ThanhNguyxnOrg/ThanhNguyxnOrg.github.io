# Tokens

All tokens live in `src/index.css` inside `@theme` (Tailwind v4 CSS-first). Each
`--color-x` becomes `bg-x`, `text-x`, `border-x`, `ring-x`, etc.

## Color

### Raw palette (brand art only)
| Token | Hex | Role |
|---|---|---|
| `midnight` | #080B14 | Canvas |
| `violet` / `violet-deep` / `violet-ink` / `violet-soft` | #8B5CF6 / #7C3AED / #6D28D9 / #C4B5FD | Brand |
| `cyan` | #22D3EE | Secondary |
| `lime` | #C4F750 | Spark |
| `coral` | #FB7185 | Contrast spark |
| `ink-50 … ink-900` | neutrals tinted toward midnight | Neutrals |

### Semantic (use these in components)
| Token | Use | Contrast on `bg` |
|---|---|---|
| `bg` | Page canvas | — |
| `surface` | Cards, panels, inputs | — |
| `surface-raised` | Hover fill, nested blocks, skeletons, tags | — |
| `border` | Hairlines, dividers | — |
| `border-strong` | Input borders, secondary button border | — |
| `fg` | Headings, primary text | 18.1:1 |
| `fg-soft` | Long body copy | ~12:1 |
| `fg-muted` | Supporting text, labels | 8.4:1 |
| `fg-subtle` | Metadata, placeholders only (not paragraphs) | 5.9:1 |
| `primary` | Brand accent: borders, glyphs, indices, gradient | 4.6:1 (non-text/large only) |
| `primary-fill` / `primary-fill-hover` | Primary button background | white text 5.7 / 7.1:1 |
| `primary-text` | Violet text on dark | 10.6:1 |
| `on-primary` | Text on primary fill | — |
| `secondary` | Links, interactive accents | 10.9:1 |
| `on-secondary` | Text on cyan | — |
| `highlight` / `on-highlight` | Lime spark (featured badge, "now" node, selection) | 15.7:1 pair |
| `contrast` | Coral spark (category accent, rare) | — |
| `focus` | Focus outline (cyan) | — |
| `success` / `warning` / `error` | State colors (always with icon/label) | ≥ 4.5:1 |
| `error-text` | Error message text | 10.4:1 |

Opacity modifiers are allowed for tints: `bg-primary/10`, `border-secondary/40`.

## Typography

```
--font-display: 'Space Grotesk', ui-sans-serif, system-ui, …
--font-sans:    'Inter', ui-sans-serif, system-ui, …
--font-mono:    'JetBrains Mono', ui-monospace, SFMono-Regular, …
```
Loaded via Google Fonts CSS2 import at the top of `index.css` (weights: Inter 400–700,
Space Grotesk 400–700, JetBrains Mono 400–600, `display=swap`).

| Class | Size (fluid) | LH | Tracking | Font / weight | Use |
|---|---|---|---|---|---|
| `text-display-2xl` | 48 → 112px | .92 | -4.5% | display 600 | Page hero only (one per page) |
| `text-display-xl` | 40 → 76px | .98 | -4% | display 600 | Section titles |
| `text-display-lg` | 32 → 52px | 1.04 | -3% | display 600 | Featured titles, big stats |
| `text-display-md` | 24 → 34px | 1.12 | -2% | display 600 | Subheads, stat values |
| `text-title` | 20px | 1.3 | -1% | display 600 | Card titles |
| `text-body-lg` | 18px | 1.65 | 0 | sans 400 | Lead paragraphs |
| `text-body` | 16px | 1.6 | 0 | sans 400 | Body |
| `text-body-sm` | 14px | 1.55 | 0 | sans 400–600 | UI, buttons, summaries |
| `text-label` | 12px | 1.2 | +8% | mono 500, uppercase | Meta labels, tags |
| `text-micro` | 11px | 1.2 | +10% | mono, uppercase | Badges, captions |

Rules: never set display fonts below `text-title`; never use mono for paragraphs;
add `text-balance` to multi-line headings.

## Measure (max widths)
`max-w-page` 80rem (page), `max-w-reading` 42rem (~68ch body), `max-w-measure` 34rem (short leads).

## Radius
`rounded-xs` 4 (tags) · `sm` 6 (small buttons) · `md` 10 (buttons, inputs) · `lg` 16 (cards, panels) ·
`xl` 24 (featured, CTA) · `pill` (badges, filters). Nest smaller radii inside larger ones.

## Elevation
Dark UI uses **borders + tone**, not heavy shadow.
- Level 0: `bg` + `border-border`
- Level 1: `bg-surface` / `surface-raised` + `shadow-raised` (hover on cards)
- Glow: `shadow-glow-primary` / `shadow-glow-secondary` — interactive emphasis only.

## Brand utilities
`focus-ring`, `transition-ui` (color/bg/border/shadow/transform/opacity · fast · out-expo),
`text-gradient-brand` (violet→cyan, display text only, max once per section),
`bg-blueprint` (48px grid), `bg-aurora` (violet/cyan radial wash — hero and CTA only).

## Motion
CSS: `--duration-instant 120ms`, `fast 200ms`, `base 320ms`, `slow 600ms`, `epic 1000ms`;
`--ease-out-expo`, `--ease-in-out-quint`, `--ease-snap` (also `ease-out-expo` classes).
JS mirror for GSAP: `motionTokens` from the kit (`duration`, `ease`, `stagger`, `distance`).
See `motion.md`.
