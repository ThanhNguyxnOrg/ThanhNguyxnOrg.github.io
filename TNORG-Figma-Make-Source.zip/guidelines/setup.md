## Package Installation

**CRITICAL**: You MUST explicitly install every package listed below as a direct dependency, exactly as written.

Rules:
- Even if a package is already available as a transitive dependency (i.e., installed by another package), you MUST still add it as a direct dependency. Transitive availability does NOT count as installed.
- Use the **exact** package name shown. Packages with similar names (e.g., `@scope-a/foo` vs `@scope-b/foo`, or `foo` vs `foo-core`) are **different packages** and are NOT interchangeable. Never substitute one for another.
- This applies to your `import` statements too: import from these exact package names. Do NOT rewrite the scope to match the package this guideline ships inside, or any other scope you see in `node_modules/`. The packages below are upstream npm packages — they live under their own names, regardless of where this guideline file is located.
- Do not skip any package. Do not reorder, rename, or omit any entry.

Add the following to your `package.json` dependencies:

```json
{
  "dependencies": {
    "lucide-react": "1.55.0",
    "motion": "14.1.0",
    "@phosphor-icons/react": "2.1.10",
    "three": "0.186.1",
    "@gsap/react": "2.1.2",
    "lenis": "1.3.26",
    "zod": "4.6.5",
    "@react-three/fiber": "9.8.1",
    "@react-three/drei": "10.7.9"
  }
}
```
