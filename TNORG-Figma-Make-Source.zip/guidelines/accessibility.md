# Accessibility

Target: **WCAG 2.2 AA**. These are requirements, not suggestions.

1. **Focus**: global `:focus-visible` = 2px `focus` (cyan) outline, 3px offset. Never remove;
   use `focus-ring` on custom controls. Inputs add `shadow-glow-secondary` on focus.
2. **Targets**: min 44×44 for icon-only controls (`IconButton` md, social links); 36px rows for
   footer/list links; buttons are 36/44/52px tall.
3. **Contrast**: body text uses `fg`, `fg-soft` or `fg-muted`. `fg-subtle` (5.9:1) only for
   metadata. `primary` (violet) is not a small-text color — use `primary-text`.
4. **Not color alone**: `StatusIndicator` = shape + label + color; links are underlined;
   `FilterGroup` active state inverts fill and sets `aria-pressed`; errors include icon + text.
5. **Semantics**: `SiteNav` renders `header > nav[aria-label=Primary]` with `aria-current="page"`;
   one `h1` per page; `SectionHeader` defaults to `h2` (`as` to change); stats use `dl`;
   timelines use `ol` + `time`; cards are `article`.
6. **Labels**: `IconButton` requires `label`; `SearchField` requires `label` (use `hideLabel`
   to hide visually); external links append "(opens in a new tab)" for screen readers.
7. **Live regions**: announce filter result counts with `aria-live="polite"`; `ErrorState`
   has `role="alert"`; skeletons expose `role="status"`.
8. **Mobile nav**: toggle has `aria-expanded`/`aria-controls`; Escape closes and returns focus.
9. **Motion**: everything usable with `prefers-reduced-motion: reduce`; no content hidden
   until an animation runs.
10. **Cards**: stretched title link makes the card clickable while secondary links (Source)
    remain separately focusable above it (`relative z-10`).
