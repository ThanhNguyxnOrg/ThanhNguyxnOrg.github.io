# Motion

Motion explains **arrival and causality**. It never performs for its own sake.

## Systems
- **GSAP + `@gsap/react`**: entrances, staggered reveals, scroll-triggered entrances, demo timelines.
- **CSS (`transition-ui`)**: hover, focus, press, toggles.
- `motion` is installed but **not used**. `lenis` is **not adopted** (native scroll preserved).

## Tokens
| Token | CSS | GSAP (`motionTokens`) | Use |
|---|---|---|---|
| instant | 120ms | `duration.instant` | press, color |
| fast | 200ms | `duration.fast` | hover, focus |
| base | 320ms | `duration.base` | panels, small reveals |
| slow | 600ms | `duration.slow` | scroll entrances |
| epic | 1000ms | `duration.epic` | hero sequence only |
| ease out | `--ease-out-expo` | `ease.out` = `expo.out` | default |
| ease in-out | `--ease-in-out-quint` | `ease.inOut` | progress, wipes |
| snap | `--ease-snap` | `ease.snap` | tiny nodes/badges only |
| stagger | — | `stagger.tight/base/loose` = 40/80/140ms | lists |
| distance | — | `distance.sm/md/lg` = 12/24/48px | entrance offset |

## `Reveal` — the only entrance primitive
```tsx
<Reveal stagger="base">            {/* scroll-triggered, once */}
  <div data-reveal>…</div>
  <div data-reveal>…</div>
</Reveal>
<Reveal trigger="mount" stagger="loose">…</Reveal>   {/* hero only */}
```
- Children with `data-reveal` animate in sequence; otherwise the wrapper animates.
- Uses `gsap.matchMedia('(prefers-reduced-motion: no-preference)')`: with reduced motion,
  nothing runs and content is already final. `gsap.from` + `clearProps` means no-JS = visible.
- Re-key `Reveal` (e.g. `key={filter}`) to replay after filtering.

## Custom GSAP rules
- Always `useGSAP(fn, { scope: ref })` and selector strings scoped to that ref.
- Event-driven animations: wrap handlers in `contextSafe` (see `showcase/MotionDemo.tsx`).
- Register plugins once at module level: `gsap.registerPlugin(useGSAP, ScrollTrigger)`.
- Animate only `transform` and `opacity` (`autoAlpha`). No layout properties.
- `ScrollTrigger`: entrances with `once: true` only. No scroll-jacking, no pinning of
  text content, no scrub on body copy.
- Never animate the same element with CSS transitions and GSAP simultaneously.

## Hover feedback
Lift 4px (`hover:-translate-y-1`) for cards; arrow nudge 2–4px for directional actions;
glow for primary CTA. Touch devices get no hover-dependent information.

## Reduced motion
Global CSS caps transitions/animations to ~0ms; GSAP checks the media query; the
`StatusIndicator` pulse and `Skeleton` pulse are disabled with `motion-reduce:`.
