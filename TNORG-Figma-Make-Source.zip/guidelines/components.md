# Components

All exported from the kit barrel (`src/index.ts`). Props below are the public API.

## Button
`variant: 'primary' | 'secondary' | 'ghost'` · `size: 'sm' | 'md' | 'lg'` (36/44/52px) ·
`iconStart`, `iconEnd` (lucide element) · `loading` · `href` (renders `<a>`) · native attrs.
- **primary**: violet fill — one per view region (the main action).
- **secondary**: bordered surface; hover → cyan border/text. Alternative actions.
- **ghost**: low emphasis (nav-adjacent, tertiary).
- States: hover (glow on primary), focus ring, active 1px press, disabled 40% opacity,
  loading (spinner, `aria-busy`, disabled). `buttonClasses()` exposes styles for other elements.
```tsx
<Button iconEnd={<ArrowRight />} href="/projects">Explore projects</Button>
<Button variant="secondary" loading>Deploying</Button>
```

## IconButton
`label` (required, becomes aria-label + title) · `icon` · `variant: 'ghost' | 'secondary'` · `size: 'sm' | 'md'` (36/44).

## TextLink
`external` (new tab + ↗ + SR hint) · `tone: 'default' | 'muted'`. Always underlined.

## Badge · Tag · MetaLabel · StatusIndicator
- `Badge tone="neutral|primary|secondary|highlight|contrast"` — category. `highlight` max once per view.
- `Tag` — technology chip, lowercase mono, non-interactive.
- `MetaLabel index="TN-014"` — mono `index / text`. Use above every section/card title.
- `StatusIndicator status="active|beta|experimental|archived" pulse?` — dot shape differs
  (circle / circle / diamond / hollow) + label.

## ProjectCard
`project: Project` · `headingLevel?: 2|3|4` · `footer?`.
`Project = { id, code, title, summary, category, categoryTone?, status, technologies[], href?, repoHref?, image?, glyph?: { pattern: 'orbit'|'grid'|'stack'|'wave', accent }, year? }`.
Anatomy: media (16:9 image or `ProjectGlyph`) + category badge → MetaLabel + status →
title (stretched link) → 3-line summary → tech tags → Source link.
Hover: lift 4px, border-strong, raised shadow, media scale 1.03. Grid: 1 / 2 (`sm`) / 3 (`lg`).

## FeaturedProject
`project` · `highlights?: {value,label}[]` (≤3) · `reverse?`.
7/5 asymmetric split at `lg`, stacked below. One per section; never in the card grid.

## ProjectGlyph
`pattern`, `accent` — generative SVG cover. Use when no screenshot exists. Prefer over WebGL.

## SearchField
`label` (required) · `value` · `onValueChange` · `hideLabel?` · `hint?` · `error?`.
Clear button appears with a value. `error` sets `aria-invalid` and red border + text.
With zod: `schema.safeParse(v)` → pass `issues[0].message` to `error`.

## FilterGroup
`label` · `options: {value,label,count?}[]` · `value` · `onChange`. Single-select toggle
buttons (`aria-pressed`); active = inverted fill. Horizontal scroll on mobile.

## EmptyState · ErrorState · Skeleton · ProjectCardSkeleton
- `EmptyState { title, description?, icon?, action? }` — always offer an action (reset filters).
- `ErrorState { title, description?, action? }` — `role="alert"`, retry action.
- `Skeleton className` / `ProjectCardSkeleton` — match final geometry to avoid layout shift.

## SectionHeader
`index?` · `eyebrow` · `title` · `description?` · `action?` · `as?: 'h1'|'h2'|'h3'` (default h2).
8/4 split at `lg`: title left, description + action right, bottom-aligned.

## Stat · StatGroup
`StatGroup` (`dl`, 2 → 4 cols) wraps `Stat { value, label, detail?, accent?: 'none'|'primary'|'secondary'|'highlight' }`.
Accent = left rule color; use at most two accents per group.

## Timeline · TimelineItem
`TimelineItem { date, title, description?, tags?, current? }` inside `Timeline` (`ol`).
Date column (9rem) on `md+`, stacked on mobile; `current` = lime diamond + "Now".

## CTASection
`eyebrow` · `title` · `description?` · `actions`. One per page, near the end.
Actions: one primary + one ghost/secondary.

## SiteNav
`items: {label,href}[]` · `currentHref?` · `action?` · `homeHref?` · `sticky?`.
Desktop inline links with violet underline on current; mobile disclosure panel with
numbered display-size links.

## SiteFooter
`columns: {title, links[{label,href,external?}]}[]` · `socials: {label,href,icon}[]` · `tagline` · `legal`.

## Container · Logo · LogoMark · GitHubMark · Reveal
- `Container as? id? className?` — page width + gutters.
- `Logo showDescriptor?`, `LogoMark title?` — bracket + slash + lime node mark.
- `Reveal` — see `motion.md`.

## Not included (intentionally)
Modals, tabs, dropdowns, toasts, forms beyond search. Build them only when a real page
needs them, from these tokens and the same state rules.
