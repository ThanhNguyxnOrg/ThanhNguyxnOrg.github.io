# TNORG Creative System

The design system for **TNORG (ThanhNguyxnOrg)** — an independent technology lab
building open-source software, developer tools and experimental products.
Direction: **Creative Developer Portfolio × Independent Tech Lab**. Expressive,
colorful and slightly futuristic, but technically credible and strict.

## Reading order

1. `Guidelines.md` — this file (principles, boundaries, file map)
2. `setup.md` — required dependencies
3. `tokens.md` — color, type, radius, elevation, motion tokens
4. `components.md` — read BEFORE using any component
5. `styles.md` — layout, grid, spacing, responsive composition
6. `motion.md` — read BEFORE adding animation
7. `accessibility.md` — non-negotiable rules
8. `icon-discovery.md` — read BEFORE using icons

## Identity in five rules

1. **Midnight first.** The canvas is always `bg` (#080B14). No light theme in v0.1.
2. **Accents are earned.** Area ratio ≈ 62 midnight / 20 violet / 11 cyan / 5 lime / 2 coral.
   Violet = brand & primary action. Cyan = interaction & focus. Lime and coral are
   single sparks (one per view), never adjacent.
3. **Three voices.** Space Grotesk speaks (display), Inter explains (UI/body),
   JetBrains Mono annotates (labels, IDs, metadata).
4. **The index is the signature.** Mono identifiers (`01 / Color`, `TN-014`) tag
   sections and projects. Use `MetaLabel`.
5. **Editorial asymmetry.** Use 7/5 and 8/4 column splits, oversized headings and
   negative space. Avoid walls of identical cards.

## Package boundaries (decided — do not re-litigate per screen)

| Need | Use | Do not use |
|---|---|---|
| Styling & tokens | Tailwind v4 `@theme` in `src/index.css` | Raw hex / px in components |
| Icons | `lucide-react` + local `GitHubMark` | `@phosphor-icons/react` (installed, unused) |
| Choreography | `gsap` + `@gsap/react` (`useGSAP`), `ScrollTrigger` for scroll entrances | `motion` (installed, unused — never two animation systems) |
| Hover / micro feedback | CSS `transition-ui` | GSAP for hover |
| Smooth scroll | Native scrolling | `lenis` — not adopted: native scroll + anchor jumps are preferable for a docs/portfolio site |
| Decorative geometry | SVG (`ProjectGlyph`, `LogoMark`), CSS backgrounds (`bg-blueprint`, `bg-aurora`) | `three` / R3F / Drei — reserved for a genuine interactive 3D project page, lazy-loaded, with DOM fallback |
| Validation | `zod` for form/data schemas, mapped to `SearchField`-style `error` text | — |

## Import

```tsx
import { Button, ProjectCard, SectionHeader, Reveal } from '<kit package name>'
// inside this repo: import { … } from './index'
```
`src/index.ts` is the barrel and also imports `index.css` (tokens + fonts).

## Core rules

1. Compose from kit components; never write raw `<button>`, `<a>`, `<input>` or
   `<h1>–<h3>` in product code when a component exists.
2. Use semantic tokens (`bg-surface`, `text-fg-muted`, `bg-primary-fill`), never raw palette
   (`bg-violet`) except in brand illustrations.
3. Glow (`shadow-glow-*`) only on interactive emphasis (primary button hover, focused input).
4. One `FeaturedProject` per section; one `CTASection` per page; one `highlight` badge per view.
5. Every animation must leave content final and readable with motion disabled.
6. Status, validity and selection are never conveyed by color alone.

## Portability (Astro + Tailwind v4)

- Copy the `@theme` block, `@utility` rules and base layer from `src/index.css` into the
  Astro site's global CSS unchanged — token names are framework-agnostic.
- Static components (`Badge`, `Tag`, `MetaLabel`, `StatusIndicator`, `ProjectCard`,
  `FeaturedProject`, `SectionHeader`, `Stat`, `Timeline`, `CTASection`, `SiteFooter`,
  `Container`) are pure markup: port to `.astro` or render as React without hydration.
- Hydrate as islands only: `SiteNav` (`client:media="(max-width: 767px)"` or `client:idle`),
  project filtering (`SearchField` + `FilterGroup`), and `Reveal`/GSAP sections (`client:visible`).
