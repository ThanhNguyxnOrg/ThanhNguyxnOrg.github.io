# Layout, spacing & responsive composition

## Spacing
Tailwind's 4px scale. Preferred steps: 1, 2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 28.
- Inside components: 1.5–6 (6–24px).
- Between related blocks: 6–10.
- Between section header and content: `mt-14`.
- Section padding: `py-20 md:py-28`. Sections are separated by `border-t border-border`.

## Container
`<Container>` = `mx-auto max-w-page px-5 md:px-8 lg:px-12`. Never nest containers.

## Breakpoints & grid
| Breakpoint | Min | Columns | Gap | Behaviour |
|---|---|---|---|---|
| base | 0 | 4 (content stacks) | 12px | Drawer nav, filters scroll horizontally, cards 1-up |
| `sm` | 640 | — | — | Cards 2-up allowed |
| `md` | 768 | 8 | 12–24px | Inline nav, 2-up cards |
| `lg` | 1024 | 12 | 24px | Asymmetric splits, 3-up cards |
| `xl`/`2xl` | 1280+ | 12 | 24px | Container stops growing |

Composition, not shrinking: on `lg` use 7/5 (media/copy) or 8/4 (title/description)
splits; below `lg` stack with copy first only when the media is decorative.

## Section anatomy
```tsx
<Container as="section" id="tools" className="border-t border-border py-20 md:py-28">
  <SectionHeader index="02" eyebrow="Developer tools" title="Tools we use daily." description="…" />
  <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">…</div>
</Container>
```

## Surfaces & borders
- Cards/panels: `rounded-lg border border-border bg-surface`.
- Tables of tokens/rules: `gap-px bg-border` grid with `bg-bg` cells (hairline grid).
- Dashed `border-border-strong` = placeholder / empty / "coming next".

## Backgrounds
`bg-aurora` + `bg-blueprint` with a mask: hero and CTA only. Elsewhere plain `bg`.

## Do / Don't
- Do vary rhythm: featured block → filter bar → 3-up grid → timeline.
- Don't place more than one gradient text per section, or glow on static cards.
- Don't hardcode px/hex in class names; extend `@theme` instead.
