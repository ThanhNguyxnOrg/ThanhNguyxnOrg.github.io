# TNORG Creative System — exported from Figma Make

This folder contains the React + TypeScript source retrieved from the Figma Make project.

## Requirements
- Node.js 20.19+ (or a compatible current LTS release)
- npm

## Run locally

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (normally `http://localhost:5173`).

## Build for production

```bash
npm run build
npm run preview
```

## Notes
- `vite.config.ts` is a portable Vite config for running the app outside Figma Make. The original Figma-specific config was preserved as `vite.config.figma.ts` for reference.
- The exported source includes the app, components, site sections, design tokens/styles, and the Figma-provided guideline documents in `guidelines/`.
- The original Figma Make environment may have additional private/runtime metadata that is not part of the source files returned during this export.
